package com.project.expensescalculatorv2;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Push {

    Calendar c = Calendar.getInstance();
    SimpleDateFormat monthAndYearFormat = new SimpleDateFormat("MMMM-YYYY");
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/HH:mm:ss");

    String month_year = monthAndYearFormat.format(c.getTime());
    String date = dateFormat.format(c.getTime());

    FirebaseDatabase db = FirebaseDatabase.getInstance();
    DatabaseReference dbRef = db.getReference(month_year);

    public void Update(Object finalData) {
        dbRef.child(date).setValue(finalData);
    }

}
