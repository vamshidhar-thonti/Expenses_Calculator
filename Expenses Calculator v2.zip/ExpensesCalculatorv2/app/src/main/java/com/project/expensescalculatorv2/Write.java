package com.project.expensescalculatorv2;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.zip.Inflater;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Write#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Write extends Fragment {

    EditText amount;
    Button update;
    TextView date;

    ExpensesData data;
    Push push;

    public Write() {
        // Required empty public constructor
    }

    public static Write newInstance() {
        Write fragment = new Write();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        push = new Push();
        data = new ExpensesData();

        View v = inflater.inflate(R.layout.fragment_write, container, false);
        amount = v.findViewById(R.id.expenseAmount);
        update = v.findViewById(R.id.saveData);
        date = v.findViewById(R.id.date);

        date.setText(data.getCurrentDate()); //set date to the textView

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //Check if the editText field is empty
                if(amount.getText().toString().trim().equalsIgnoreCase("")){
                    amount.setError("Are you mad!");
                } else {
                    data.setAmount(Double.parseDouble(amount.getText().toString().trim())); //get amount form the field and set to the ExpensesData class
                    push.Update(data); //Call the method which updates/writes the data to the firebase
                    amount.setText("");
                }
            }
        });

        return v;
    }
}